#include <iostream>
#include <cstdlib>
#include <limits>
#include <windows.h>
#include <tlhelp32.h>
#include <string>
#include <vector>
#include <atomic>
#include <shellapi.h>
#include <commctrl.h>
#include <conio.h>

using namespace std;

// ---------- 全局变量 ----------
HHOOK g_kbdHook = NULL;
atomic<bool> g_hookThreadRunning(false);
HANDLE g_hookThreadHandle = NULL;

NOTIFYICONDATAW g_notifyData = {0};
bool g_trayCreated = false;
HWND g_hiddenWnd = NULL;
atomic<bool> g_quitRequested(false);
atomic<bool> g_hideToTray(false);
atomic<bool> g_needRefresh(false);

#define HOTKEY_KILL_JIYU      1
#define HOTKEY_EXIT_FULL      2
#define HOTKEY_TOGGLE_CONSOLE 3
#define WM_TRAYICON (WM_APP + 1)

// ---------- 前向声明 ----------
void printMenu();

// ---------- 工具函数 ----------
void clearScreen() { system("cls"); }
void pauseScreen() { system("pause"); }

// ---------- 进程/线程操作 ----------
DWORD GetProcessIdByName(const string& processName) {
    HANDLE hSnapshot = CreateToolhelp32Snapshot(TH32CS_SNAPPROCESS, 0);
    if (hSnapshot == INVALID_HANDLE_VALUE) return 0;
    PROCESSENTRY32 pe = { sizeof(pe) };
    if (Process32First(hSnapshot, &pe)) {
        do {
            if (processName == pe.szExeFile) {
                CloseHandle(hSnapshot);
                return pe.th32ProcessID;
            }
        } while (Process32Next(hSnapshot, &pe));
    }
    CloseHandle(hSnapshot);
    return 0;
}

int SuspendProcessThreads(DWORD pid) {
    HANDLE hSnapshot = CreateToolhelp32Snapshot(TH32CS_SNAPTHREAD, 0);
    if (hSnapshot == INVALID_HANDLE_VALUE) return -1;
    int count = 0;
    THREADENTRY32 te = { sizeof(te) };
    if (Thread32First(hSnapshot, &te)) {
        do {
            if (te.th32OwnerProcessID == pid) {
                HANDLE hThread = OpenThread(THREAD_SUSPEND_RESUME, FALSE, te.th32ThreadID);
                if (hThread) {
                    if (SuspendThread(hThread) != (DWORD)-1) count++;
                    CloseHandle(hThread);
                }
            }
        } while (Thread32Next(hSnapshot, &te));
    }
    CloseHandle(hSnapshot);
    return count;
}

int ResumeProcessThreads(DWORD pid) {
    HANDLE hSnapshot = CreateToolhelp32Snapshot(TH32CS_SNAPTHREAD, 0);
    if (hSnapshot == INVALID_HANDLE_VALUE) return -1;
    int count = 0;
    THREADENTRY32 te = { sizeof(te) };
    if (Thread32First(hSnapshot, &te)) {
        do {
            if (te.th32OwnerProcessID == pid) {
                HANDLE hThread = OpenThread(THREAD_SUSPEND_RESUME, FALSE, te.th32ThreadID);
                if (hThread) {
                    if (ResumeThread(hThread) != (DWORD)-1) count++;
                    CloseHandle(hThread);
                }
            }
        } while (Thread32Next(hSnapshot, &te));
    }
    CloseHandle(hSnapshot);
    return count;
}

bool KillProcessByAPI(DWORD pid) {
    HANDLE hProcess = OpenProcess(PROCESS_TERMINATE, FALSE, pid);
    if (hProcess) {
        if (TerminateProcess(hProcess, 0)) {
            CloseHandle(hProcess);
            return true;
        }
        CloseHandle(hProcess);
    }
    HANDLE hSnapshot = CreateToolhelp32Snapshot(TH32CS_SNAPTHREAD, pid);
    if (hSnapshot == INVALID_HANDLE_VALUE) return false;
    bool ok = false;
    THREADENTRY32 te = { sizeof(te) };
    if (Thread32First(hSnapshot, &te)) {
        do {
            if (te.th32OwnerProcessID == pid) {
                HANDLE hThread = OpenThread(THREAD_TERMINATE, FALSE, te.th32ThreadID);
                if (hThread) {
                    if (TerminateThread(hThread, 0)) ok = true;
                    CloseHandle(hThread);
                }
            }
        } while (Thread32Next(hSnapshot, &te));
    }
    CloseHandle(hSnapshot);
    return ok;
}

// ---------- 键盘钩子 ----------
LRESULT CALLBACK LowLevelKeyboardProc(int nCode, WPARAM wParam, LPARAM lParam) {
    return 1;
}

DWORD WINAPI KeyHookThreadProc(LPVOID) {
    g_hookThreadRunning = true;
    while (g_hookThreadRunning) {
        g_kbdHook = SetWindowsHookEx(WH_KEYBOARD_LL, LowLevelKeyboardProc,
                                     GetModuleHandle(NULL), 0);
        if (g_kbdHook) {
            Sleep(50);
            UnhookWindowsHookEx(g_kbdHook);
            g_kbdHook = NULL;
        }
        Sleep(50);
    }
    return 0;
}

// ---------- 功能1 ----------
void killJiyu() {
    STARTUPINFOA si = { sizeof(si) };
    PROCESS_INFORMATION pi = { 0 };
    char cmd[] = "taskkill /F /IM StudentMain.exe";
    if (CreateProcessA(NULL, cmd, NULL, NULL, FALSE, CREATE_NO_WINDOW, NULL, NULL, &si, &pi)) {
        WaitForSingleObject(pi.hProcess, INFINITE);
        DWORD exitCode = 0;
        GetExitCodeProcess(pi.hProcess, &exitCode);
        CloseHandle(pi.hProcess);
        CloseHandle(pi.hThread);
        if (exitCode == 0) {
            cout << "[成功] 已通过 taskkill 杀死极域。" << endl;
            return;
        } else {
            cout << "[信息] taskkill 未找到极域进程，尝试备用方法..." << endl;
        }
    } else {
        cout << "[信息] 无法启动 taskkill，尝试备用方法..." << endl;
    }
    DWORD pid = GetProcessIdByName("StudentMain.exe");
    if (pid == 0) {
        cout << "[失败] 未找到极域进程 (StudentMain.exe)。" << endl;
        return;
    }
    if (KillProcessByAPI(pid))
        cout << "[成功] 已通过 API 强制杀死极域。" << endl;
    else
        cout << "[失败] 所有方法均无法杀死极域。请检查权限或进程是否存在。" << endl;
}

// ---------- 功能2 ----------
void suspendJiyu() {
    clearScreen();
    cout << "========================================" << endl;
    cout << "         挂起 / 恢复 极域               " << endl;
    cout << "========================================" << endl;
    cout << "  1. 挂起极域                          " << endl;
    cout << "  2. 恢复极域                          " << endl;
    cout << "========================================" << endl;
    cout << "请输入选项 (1-2): ";
    int subChoice;
    cin >> subChoice;
    if (cin.fail()) {
        cin.clear();
        cin.ignore(numeric_limits<streamsize>::max(), '\n');
        cout << "[错误] 输入无效。" << endl;
        return;
    }
    DWORD pid = GetProcessIdByName("StudentMain.exe");
    if (pid == 0) {
        cout << "[失败] 未找到极域进程。" << endl;
        return;
    }
    int result = -1;
    string action;
    switch (subChoice) {
        case 1: result = SuspendProcessThreads(pid); action = "挂起"; break;
        case 2: result = ResumeProcessThreads(pid);  action = "恢复"; break;
        default: cout << "[错误] 无效选项。" << endl; return;
    }
    if (result >= 0)
        cout << "[成功] " << action << "了 " << result << " 个线程。" << endl;
    else
        cout << "[失败] " << action << "操作失败。" << endl;
}

// ---------- 功能3 ----------
void killAssistant() {
    HKEY hKey;
    LONG ret = RegOpenKeyExA(HKEY_LOCAL_MACHINE,
                             "SOFTWARE\\WOW6432Node\\ZM软件工作室\\学生机房管理助手",
                             0,
                             KEY_QUERY_VALUE | KEY_WOW64_32KEY,
                             &hKey);
    if (ret != ERROR_SUCCESS) {
        cout << "[失败] 未找到机房管理助手注册表项。" << endl;
        return;
    }
    char version[10] = {0};
    DWORD size = sizeof(version);
    ret = RegQueryValueExA(hKey, "Version", NULL, NULL, (LPBYTE)version, &size);
    RegCloseKey(hKey);
    if (ret != ERROR_SUCCESS) {
        cout << "[失败] 读取版本信息失败。" << endl;
        return;
    }
    if (version[0] != '7') {
        cout << "[信息] 仅支持主版本 7，当前版本：" << version << endl;
        return;
    }
    char subVer = version[2];
    SYSTEMTIME st;
    GetLocalTime(&st);
    int n3 = st.wMonth * st.wDay;

    DWORD prozsPid = 0;
    string prozsName;

    if (subVer == '5' || subVer == '8') {
        HANDLE hSnapshot = CreateToolhelp32Snapshot(TH32CS_SNAPPROCESS, 0);
        if (hSnapshot != INVALID_HANDLE_VALUE) {
            PROCESSENTRY32 pe = { sizeof(pe) };
            if (Process32First(hSnapshot, &pe)) {
                do {
                    string exe = pe.szExeFile;
                    size_t len = exe.length();
                    bool match = false;
                    if (subVer == '5') {
                        if (len == 14) {
                            match = true;
                            for (size_t i = 0; i < 10; ++i) {
                                unsigned char ch = exe[i];
                                if (ch < 100 || ch > 109) { match = false; break; }
                            }
                        }
                    } else { // '8'
                        if (len >= 8) {
                            size_t nameLen = len - 4;
                            if (nameLen > 0) {
                                match = true;
                                for (size_t i = 0; i < nameLen; ++i) {
                                    unsigned char ch = exe[i];
                                    if (ch < 100 || ch > 109) { match = false; break; }
                                }
                            }
                        }
                    }
                    if (match) {
                        prozsPid = pe.th32ProcessID;
                        prozsName = exe;
                        break;
                    }
                } while (Process32Next(hSnapshot, &pe));
            }
            CloseHandle(hSnapshot);
        }
        if (prozsPid == 0) {
            cout << "[失败] 未找到 " << (subVer == '5' ? "7.5" : "7.8") << " 版本的随机进程。" << endl;
            return;
        }
    } else if (subVer == '4') {
        int n4 = n3 % 7, n5 = n3 % 5, n6 = n3 % 3;
        int n = n3 % 9;
        char c1, c2, c3, c4;
        if (n3 % 2 == 0) {
            c1 = 108 + n4; c2 = 75 + n; c3 = 98 + n5; c4 = 65 + n6;
        } else {
            c1 = 98 + n; c2 = 65 + n4; c3 = 108 + n5; c4 = 75 + n6;
        }
        char fullName[9];
        fullName[0] = c1; fullName[1] = c2; fullName[2] = c3; fullName[3] = c4;
        fullName[4] = '.'; fullName[5] = 'e'; fullName[6] = 'x'; fullName[7] = 'e'; fullName[8] = '\0';
        prozsPid = GetProcessIdByName(fullName);
        prozsName = fullName;
        if (prozsPid == 0) {
            cout << "[失败] 未找到 7.4 版本的随机进程 (" << fullName << ")。" << endl;
            return;
        }
    } else if (subVer == '2') {
        int n4 = n3 % 7, n5 = n3 % 9, n6 = n3 % 5;
        char c1, c2, c3, c4;
        if (n3 % 2 != 0) {
            c1 = 103 + n5; c2 = 111 + n4; c3 = 107 + n6; c4 = 48 + n4;
        } else {
            c1 = 97 + n4; c2 = 109 + n5; c3 = 101 + n6; c4 = 48 + n5;
        }
        char fullName[9];
        fullName[0] = c1; fullName[1] = c2; fullName[2] = c3; fullName[3] = c4;
        fullName[4] = '.'; fullName[5] = 'e'; fullName[6] = 'x'; fullName[7] = 'e'; fullName[8] = '\0';
        prozsPid = GetProcessIdByName(fullName);
        prozsName = fullName;
        if (prozsPid == 0) {
            cout << "[失败] 未找到 7.2 版本的随机进程 (" << fullName << ")。" << endl;
            return;
        }
    } else {
        int n4 = n3 % 3 + 3;
        int n5 = n3 % 4 + 4;
        char c1 = 'p';
        char c2, c3;
        if (n3 % 2 != 0) {
            c2 = n4 + 102; c3 = n5 + 98;
        } else {
            c2 = n4 + 99; c3 = n5 + 106;
        }
        char fullName[8];
        fullName[0] = c1; fullName[1] = c2; fullName[2] = c3;
        fullName[3] = '.'; fullName[4] = 'e'; fullName[5] = 'x'; fullName[6] = 'e'; fullName[7] = '\0';
        prozsPid = GetProcessIdByName(fullName);
        prozsName = fullName;
        if (prozsPid == 0) {
            cout << "[失败] 未找到早期版本的随机进程 (" << fullName << ")。" << endl;
            return;
        }
    }

    if (KillProcessByAPI(prozsPid))
        cout << "[成功] 已终止 prozs 进程 (" << prozsName << ")。" << endl;
    else
        cout << "[失败] 无法终止 prozs 进程 (" << prozsName << ")。" << endl;

    DWORD pidJf = GetProcessIdByName("jfglzs.exe");
    if (pidJf != 0) {
        if (KillProcessByAPI(pidJf))
            cout << "[成功] 已终止 jfglzs.exe。" << endl;
        else
            cout << "[失败] 无法终止 jfglzs.exe。" << endl;
    } else {
        cout << "[信息] 未找到 jfglzs.exe 进程。" << endl;
    }

    SC_HANDLE hSCM = OpenSCManager(NULL, NULL, SC_MANAGER_CONNECT);
    if (hSCM) {
        SC_HANDLE hSvc = OpenServiceA(hSCM, "zmserv", SERVICE_STOP);
        if (hSvc) {
            SERVICE_STATUS ss;
            if (ControlService(hSvc, SERVICE_CONTROL_STOP, &ss))
                cout << "[成功] 已停止 zmserv 服务。" << endl;
            else
                cout << "[失败] 无法停止 zmserv 服务。" << endl;
            CloseServiceHandle(hSvc);
        } else {
            cout << "[信息] 未找到 zmserv 服务。" << endl;
        }
        CloseServiceHandle(hSCM);
    } else {
        cout << "[失败] 无法打开服务控制管理器。" << endl;
    }
}

// ---------- 功能4 ----------
BOOL CALLBACK FindBroadcastWindow(HWND hWnd, LPARAM lParam) {
    wchar_t windowTitle[256];
    GetWindowTextW(hWnd, windowTitle, 256);
    if (wcsstr(windowTitle, L"屏幕广播") != NULL) {
        HWND* pResult = (HWND*)lParam;
        *pResult = hWnd;
        return FALSE;
    }
    return TRUE;
}

void exitFullScreen() {
    HWND hWnd = NULL;
    EnumWindows(FindBroadcastWindow, (LPARAM)&hWnd);
    if (hWnd == NULL) {
        cout << "[失败] 未找到屏幕广播窗口，请确认是否正在全屏广播。" << endl;
        return;
    }
    WPARAM wParam = MAKEWPARAM(1004, BM_CLICK);
    if (PostMessage(hWnd, WM_COMMAND, wParam, 0)) {
        cout << "[成功] 已发送窗口化命令，请检查极域广播窗口是否变为窗口模式。" << endl;
    } else {
        cout << "[失败] 发送命令失败，可能窗口无响应或权限不足。" << endl;
    }
}

// ---------- 功能5 ----------
void getPassword() {
    HKEY hKey;
    LONG ret = RegOpenKeyExA(HKEY_LOCAL_MACHINE,
                             "SOFTWARE\\TopDomain\\e-Learning Class\\Student",
                             0,
                             KEY_READ | KEY_WOW64_32KEY,
                             &hKey);
    if (ret != ERROR_SUCCESS) {
        ret = RegOpenKeyExA(HKEY_LOCAL_MACHINE,
                            "SOFTWARE\\TopDomain\\e-Learning Class\\Student",
                            0,
                            KEY_READ,
                            &hKey);
        if (ret != ERROR_SUCCESS) {
            cout << "[失败] 无法打开注册表键，可能未安装极域学生端。" << endl;
            goto fallback;
        }
    }

    {
        DWORD type = 0;
        DWORD dataLen = 0;
        ret = RegQueryValueExA(hKey, "Knock1", NULL, &type, NULL, &dataLen);
        if (ret != ERROR_SUCCESS || type != REG_BINARY || dataLen == 0) {
            RegCloseKey(hKey);
            cout << "[失败] 未找到 Knock1 数据或数据格式错误。" << endl;
            goto fallback;
        }

        vector<BYTE> buffer(dataLen);
        ret = RegQueryValueExA(hKey, "Knock1", NULL, NULL, buffer.data(), &dataLen);
        RegCloseKey(hKey);
        if (ret != ERROR_SUCCESS) {
            cout << "[失败] 读取 Knock1 数据失败。" << endl;
            goto fallback;
        }

        if (dataLen % 4 != 0) {
            cout << "[失败] 加密数据长度异常。" << endl;
            goto fallback;
        }

        for (DWORD i = 0; i < dataLen; i += 4) {
            buffer[i]     ^= 0x15;
            buffer[i + 1] ^= 0x0F;
            buffer[i + 2] ^= 0x0F;
            buffer[i + 3] ^= 0x15;
        }

        BYTE startIndex = buffer[0];
        if (startIndex >= dataLen) {
            cout << "[失败] 起始索引超出范围。" << endl;
            goto fallback;
        }

        string password;
        for (DWORD i = startIndex; i < dataLen; i += 2) {
            if (buffer[i] == 0) break;
            password.push_back(static_cast<char>(buffer[i]));
        }

        if (!password.empty()) {
            cout << "[成功] 极域学生端密码为：" << password << endl;
            return;
        } else {
            cout << "[警告] 获取的密码为空。" << endl;
        }
    }

fallback:
    cout << "[提示] 未读取到密码，极域默认密码为: mythware_super_password" << endl;
}

// ---------- 功能6 ----------
void liberateFunction() {
    bool allSuccess = true;
    HKEY hKey;
    LONG ret = RegOpenKeyExA(HKEY_CURRENT_USER,
                             "Software\\Policies\\Microsoft\\Windows\\System",
                             0, KEY_SET_VALUE, &hKey);
    if (ret == ERROR_SUCCESS) {
        ret = RegDeleteValueA(hKey, "DisableCMD");
        if (ret == ERROR_SUCCESS || ret == ERROR_FILE_NOT_FOUND)
            cout << "[成功] 解除 CMD 限制。" << endl;
        else { cout << "[失败] 解除 CMD 限制失败。" << endl; allSuccess = false; }
        RegCloseKey(hKey);
    } else cout << "[信息] CMD 限制未启用。" << endl;

    ret = RegOpenKeyExA(HKEY_CURRENT_USER,
                        "Software\\Microsoft\\Windows\\CurrentVersion\\Policies\\System",
                        0, KEY_SET_VALUE, &hKey);
    if (ret == ERROR_SUCCESS) {
        ret = RegDeleteValueA(hKey, "DisableRegistryTools");
        if (ret == ERROR_SUCCESS || ret == ERROR_FILE_NOT_FOUND)
            cout << "[成功] 解除注册表编辑器限制。" << endl;
        else { cout << "[失败] 解除注册表编辑器限制失败。" << endl; allSuccess = false; }
        RegCloseKey(hKey);
    } else cout << "[信息] 注册表编辑器限制未启用。" << endl;

    ret = RegOpenKeyExA(HKEY_CURRENT_USER,
                        "Software\\Microsoft\\Windows\\CurrentVersion\\Policies\\System",
                        0, KEY_SET_VALUE, &hKey);
    if (ret == ERROR_SUCCESS) {
        ret = RegDeleteValueA(hKey, "DisableTaskMgr");
        if (ret == ERROR_SUCCESS || ret == ERROR_FILE_NOT_FOUND)
            cout << "[成功] 解除任务管理器限制。" << endl;
        else { cout << "[失败] 解除任务管理器限制失败。" << endl; allSuccess = false; }
        RegCloseKey(hKey);
    } else cout << "[信息] 任务管理器限制未启用。" << endl;

    ret = RegOpenKeyExA(HKEY_CURRENT_USER,
                        "Software\\Microsoft\\Windows\\CurrentVersion\\Policies\\Explorer",
                        0, KEY_SET_VALUE, &hKey);
    if (ret == ERROR_SUCCESS) {
        ret = RegDeleteValueA(hKey, "NoRun");
        if (ret == ERROR_SUCCESS || ret == ERROR_FILE_NOT_FOUND)
            cout << "[成功] 解除 Win+R 运行限制。" << endl;
        else { cout << "[失败] 解除 Win+R 运行限制失败。" << endl; allSuccess = false; }
        RegCloseKey(hKey);
    } else cout << "[信息] Win+R 运行限制未启用。" << endl;

    ret = RegOpenKeyExA(HKEY_LOCAL_MACHINE,
                        "SOFTWARE\\Microsoft\\Windows NT\\CurrentVersion\\Image File Execution Options\\taskkill.exe",
                        0, KEY_SET_VALUE, &hKey);
    if (ret == ERROR_SUCCESS) {
        ret = RegDeleteValueA(hKey, "debugger");
        if (ret == ERROR_SUCCESS || ret == ERROR_FILE_NOT_FOUND)
            cout << "[成功] 解除 taskkill 映像劫持。" << endl;
        else { cout << "[失败] 解除 taskkill 映像劫持失败。" << endl; allSuccess = false; }
        RegCloseKey(hKey);
    } else cout << "[信息] taskkill 映像劫持未启用。" << endl;

    cout << "[提示] 为了使 Win+R 运行生效，可能需要重启资源管理器或注销重新登录。" << endl;
    if (allSuccess) cout << "[完成] 所有解禁操作已成功执行。" << endl;
    else cout << "[完成] 部分操作可能失败，请检查是否以管理员权限运行。" << endl;
}

// ---------- 功能7 ----------
void liberateKeyboard() {
    bool driverSuccess = false;
    HANDLE hDevice = CreateFileA("\\\\.\\TDKeybd",
                                 GENERIC_READ | GENERIC_WRITE,
                                 FILE_SHARE_READ,
                                 NULL, OPEN_EXISTING, 0, NULL);
    if (hDevice != INVALID_HANDLE_VALUE) {
        DWORD bytesReturned = 0;
        BOOL bEnable = TRUE;
        if (DeviceIoControl(hDevice, 0x220000, &bEnable, sizeof(bEnable),
                            NULL, 0, &bytesReturned, NULL)) {
            cout << "[成功] 通过驱动控制码启用键盘。" << endl;
            driverSuccess = true;
        } else {
            cout << "[失败] 发送驱动控制码失败（错误码：" << GetLastError() << "）。" << endl;
        }
        CloseHandle(hDevice);
    } else {
        cout << "[信息] 未找到 \\\\.\\TDKeybd 设备，跳过驱动控制码。" << endl;
    }

    if (g_hookThreadHandle == NULL) {
        g_hookThreadHandle = CreateThread(NULL, 0, KeyHookThreadProc, NULL, 0, NULL);
        if (g_hookThreadHandle != NULL) {
            cout << "[成功] 已启动键盘钩子抢占线程。" << endl;
        } else {
            cout << "[失败] 启动钩子线程失败。" << endl;
        }
    } else {
        cout << "[信息] 键盘钩子线程已在运行中。" << endl;
    }

    if (!driverSuccess && g_hookThreadHandle == NULL)
        cout << "[警告] 两种方法均未成功，键盘可能仍然受限。" << endl;
    else
        cout << "[完成] 键盘解锁操作已执行，请尝试按键测试。" << endl;
}

// ---------- 功能8 ----------
void resumeNetwork() {
    bool anySuccess = false;
    HANDLE hNetFilter = CreateFileA("\\\\.\\TDNetFilter",
                                    GENERIC_READ | GENERIC_WRITE,
                                    FILE_SHARE_READ,
                                    NULL, OPEN_EXISTING, 0, NULL);
    if (hNetFilter != INVALID_HANDLE_VALUE) {
        DWORD bytesReturned;
        if (DeviceIoControl(hNetFilter, 0x120014, NULL, 0, NULL, 0, &bytesReturned, NULL)) {
            cout << "[成功] 已向 TDNetFilter 驱动发送终止指令。" << endl;
            anySuccess = true;
        } else {
            cout << "[失败] 发送控制码失败，错误码：" << GetLastError() << endl;
        }
        CloseHandle(hNetFilter);
    } else {
        cout << "[信息] 未找到 \\\\.\\TDNetFilter 设备。" << endl;
    }

    DWORD pid = GetProcessIdByName("MasterHelper.exe");
    if (pid != 0) {
        if (KillProcessByAPI(pid)) { cout << "[成功] 已终止 MasterHelper.exe。" << endl; anySuccess = true; }
        else cout << "[失败] 无法终止 MasterHelper.exe。" << endl;
    } else cout << "[信息] 未找到 MasterHelper.exe 进程。" << endl;

    pid = GetProcessIdByName("GATESRV.exe");
    if (pid != 0) {
        if (KillProcessByAPI(pid)) { cout << "[成功] 已终止 GATESRV.exe。" << endl; anySuccess = true; }
        else cout << "[失败] 无法终止 GATESRV.exe。" << endl;
    } else cout << "[信息] 未找到 GATESRV.exe 进程。" << endl;

    SC_HANDLE hSCM = OpenSCManager(NULL, NULL, SC_MANAGER_CONNECT);
    if (hSCM) {
        SC_HANDLE hService = OpenServiceA(hSCM, "TDNetFilter", SERVICE_STOP | DELETE);
        if (hService) {
            SERVICE_STATUS ss;
            if (ControlService(hService, SERVICE_CONTROL_STOP, &ss))
                cout << "[成功] 已停止 TDNetFilter 服务。" << endl, anySuccess = true;
            else {
                DWORD err = GetLastError();
                if (err == ERROR_SERVICE_NOT_ACTIVE)
                    cout << "[信息] TDNetFilter 服务未运行。" << endl;
                else
                    cout << "[失败] 停止 TDNetFilter 服务失败，错误码：" << err << endl;
            }
            if (DeleteService(hService))
                cout << "[成功] 已删除 TDNetFilter 服务。" << endl, anySuccess = true;
            else {
                DWORD err = GetLastError();
                if (err == ERROR_SERVICE_MARKED_FOR_DELETE)
                    cout << "[信息] TDNetFilter 服务已被标记删除。" << endl;
                else
                    cout << "[失败] 删除 TDNetFilter 服务失败，错误码：" << err << endl;
            }
            CloseServiceHandle(hService);
        } else cout << "[信息] 未找到 TDNetFilter 服务。" << endl;
        CloseServiceHandle(hSCM);
    } else cout << "[失败] 无法打开服务控制管理器。" << endl;

    if (anySuccess) cout << "[完成] 解除断网操作已执行，请检查网络连接。" << endl;
    else cout << "[完成] 所有操作均未成功，可能网络限制不是由极域引起。" << endl;
}

// ---------- 托盘功能 ----------
void CreateTrayIcon(HWND hWnd) {
    if (g_trayCreated) return;
    NOTIFYICONDATAW nid = {0};
    nid.cbSize = sizeof(NOTIFYICONDATAW);
    nid.hWnd = hWnd;
    nid.uID = 100;
    nid.uFlags = NIF_ICON | NIF_MESSAGE | NIF_TIP;
    nid.uCallbackMessage = WM_TRAYICON;
    nid.hIcon = LoadIcon(NULL, IDI_APPLICATION);
    wcscpy_s(nid.szTip, L"JiYu Tool - 已隐藏");
    if (Shell_NotifyIconW(NIM_ADD, &nid)) {
        g_trayCreated = true;
        g_notifyData = nid;
    }
}

void RemoveTrayIcon() {
    if (!g_trayCreated) return;
    Shell_NotifyIconW(NIM_DELETE, &g_notifyData);
    g_trayCreated = false;
}

void ShowConsoleWindow() {
    HWND hCon = GetConsoleWindow();
    ShowWindow(hCon, SW_SHOW);
    SetForegroundWindow(hCon);
    RemoveTrayIcon();
    g_needRefresh = true;
}

void HideConsoleToTray() {
    HWND hCon = GetConsoleWindow();
    ShowWindow(hCon, SW_HIDE);
    FlushConsoleInputBuffer(GetStdHandle(STD_INPUT_HANDLE));
    if (!g_trayCreated && g_hiddenWnd) {
        CreateTrayIcon(g_hiddenWnd);
    }
}

// ---------- 控制台关闭事件 ----------
BOOL WINAPI ConsoleCtrlHandler(DWORD dwCtrlType) {
    if (dwCtrlType == CTRL_CLOSE_EVENT) {
        g_hideToTray = true;
        return TRUE;
    }
    return FALSE;
}

// ---------- 隐藏窗口消息过程 ----------
LRESULT CALLBACK WndProc(HWND hWnd, UINT msg, WPARAM wParam, LPARAM lParam) {
    switch (msg) {
        case WM_HOTKEY: {
            if (wParam == HOTKEY_KILL_JIYU) {
                killJiyu();
                clearScreen();
                printMenu();
            } else if (wParam == HOTKEY_EXIT_FULL) {
                exitFullScreen();
                clearScreen();
                printMenu();
            } else if (wParam == HOTKEY_TOGGLE_CONSOLE) {
                HWND hCon = GetConsoleWindow();
                if (IsWindowVisible(hCon)) {
                    HideConsoleToTray();
                } else {
                    ShowConsoleWindow();
                }
            }
            break;
        }
        case WM_TRAYICON: {
            if (lParam == WM_LBUTTONUP) {
                ShowConsoleWindow();
            } else if (lParam == WM_RBUTTONUP) {
                POINT pt;
                GetCursorPos(&pt);
                HMENU hMenu = CreatePopupMenu();
                AppendMenuW(hMenu, MF_STRING, 1, L"显示主界面");
                AppendMenuW(hMenu, MF_STRING, 2, L"退出");
                SetForegroundWindow(hWnd);
                int cmd = TrackPopupMenu(hMenu, TPM_RETURNCMD | TPM_NONOTIFY, pt.x, pt.y, 0, hWnd, NULL);
                DestroyMenu(hMenu);
                if (cmd == 1) {
                    ShowConsoleWindow();
                } else if (cmd == 2) {
                    RemoveTrayIcon();
                    g_quitRequested = true;
                    PostQuitMessage(0);
                }
            }
            break;
        }
        case WM_DESTROY: {
            PostQuitMessage(0);
            break;
        }
        default:
            return DefWindowProc(hWnd, msg, wParam, lParam);
    }
    return 0;
}

// ---------- 控制台输入线程（支持回显） ----------
DWORD WINAPI ConsoleInputThread(LPVOID) {
    string input;
    while (true) {
        HWND hCon = GetConsoleWindow();
        if (!IsWindowVisible(hCon)) {
            Sleep(100);
            continue;
        }

        if (_kbhit()) {
            char ch = _getch();
            if (ch == '\r' || ch == '\n') {
                if (!input.empty()) {
                    try {
                        int choice = stoi(input);
                        cout << endl;
                        if (choice == 9) {
                            g_quitRequested = true;
                            if (g_hiddenWnd) PostMessage(g_hiddenWnd, WM_QUIT, 0, 0);
                            break;
                        }
                        switch (choice) {
                            case 1: killJiyu(); break;
                            case 2: suspendJiyu(); break;
                            case 3: killAssistant(); break;
                            case 4: exitFullScreen(); break;
                            case 5: getPassword(); break;
                            case 6: liberateFunction(); break;
                            case 7: liberateKeyboard(); break;
                            case 8: resumeNetwork(); break;
                            default: cout << "[错误] 无效选项，请重新输入！" << endl; break;
                        }
                        cout << endl;
                        system("pause");
                        g_needRefresh = true;
                    } catch (...) {
                        cout << endl << "[错误] 无效输入，请输入数字。" << endl;
                        g_needRefresh = true;
                    }
                    input.clear();
                }
            } else if (ch == '\b' || ch == 8) {
                if (!input.empty()) {
                    input.pop_back();
                    cout << "\b \b";
                }
            } else if (ch >= '0' && ch <= '9') {
                input.push_back(ch);
                cout.put(ch);
            }
        } else {
            Sleep(50);
        }
    }
    return 0;
}

// ---------- 主菜单 ----------
void printMenu() {
    cout << "========================================" << endl;
    cout << "            JiYu Tool                    " << endl;
    cout << "========================================" << endl;
    cout << "  1. 杀死极域                          " << endl;
    cout << "  2. 挂起极域                          " << endl;
    cout << "  3. 杀死助手                          " << endl;
    cout << "  4. 退出全屏                          " << endl;
    cout << "  5. 获取密码                          " << endl;
    cout << "  6. 解放功能                          " << endl;
    cout << "  7. 解放键盘                          " << endl;
    cout << "  8. 解除断网                          " << endl;
    cout << "  9. 退出程序                          " << endl;
    cout << "========================================" << endl;
    cout << "  快捷键: Alt+W 杀死极域   Alt+E 退出全屏   Alt+Q 隐藏/显示窗口" << endl;
    cout << "========================================" << endl;
}

// ---------- main ----------
int main() {
    system("chcp 65001 > nul");
    SetConsoleCtrlHandler(ConsoleCtrlHandler, TRUE);

    WNDCLASSEX wc = {0};
    wc.cbSize = sizeof(WNDCLASSEX);
    wc.lpfnWndProc = WndProc;
    wc.hInstance = GetModuleHandle(NULL);
    wc.lpszClassName = "JiYuToolHiddenWnd";
    if (!RegisterClassEx(&wc)) {
        cout << "[错误] 注册窗口类失败，无法使用热键和托盘功能。" << endl;
        g_hiddenWnd = NULL;
    } else {
        g_hiddenWnd = CreateWindowEx(0, "JiYuToolHiddenWnd", "JiYuToolHidden",
                                     0, 0, 0, 0, 0, HWND_MESSAGE, NULL, wc.hInstance, NULL);
        if (g_hiddenWnd) {
            if (!RegisterHotKey(g_hiddenWnd, HOTKEY_KILL_JIYU, MOD_ALT, 'W'))
                cout << "[警告] 注册 Alt+W 热键失败。" << endl;
            else
                cout << "[信息] Alt+W 热键注册成功。" << endl;
            if (!RegisterHotKey(g_hiddenWnd, HOTKEY_EXIT_FULL, MOD_ALT, 'E'))
                cout << "[警告] 注册 Alt+E 热键失败。" << endl;
            else
                cout << "[信息] Alt+E 热键注册成功。" << endl;
            if (!RegisterHotKey(g_hiddenWnd, HOTKEY_TOGGLE_CONSOLE, MOD_ALT, 'Q'))
                cout << "[警告] 注册 Alt+Q 热键失败。" << endl;
            else
                cout << "[信息] Alt+Q 热键注册成功。" << endl;
        } else {
            cout << "[错误] 创建隐藏窗口失败。" << endl;
        }
    }

    HANDLE hInputThread = CreateThread(NULL, 0, ConsoleInputThread, NULL, 0, NULL);
    if (!hInputThread) {
        cout << "[错误] 无法创建输入线程。" << endl;
        return 1;
    }

    g_needRefresh = true;

    MSG msg;
    while (true) {
        if (PeekMessage(&msg, NULL, 0, 0, PM_REMOVE)) {
            if (msg.message == WM_QUIT) break;
            TranslateMessage(&msg);
            DispatchMessage(&msg);
        } else {
            if (g_hideToTray) {
                g_hideToTray = false;
                HideConsoleToTray();
            }
            if (g_quitRequested) break;

            if (g_needRefresh) {
                g_needRefresh = false;
                clearScreen();
                printMenu();
            }
            Sleep(100);
        }
    }

    if (g_hiddenWnd) {
        UnregisterHotKey(g_hiddenWnd, HOTKEY_KILL_JIYU);
        UnregisterHotKey(g_hiddenWnd, HOTKEY_EXIT_FULL);
        UnregisterHotKey(g_hiddenWnd, HOTKEY_TOGGLE_CONSOLE);
        DestroyWindow(g_hiddenWnd);
    }
    RemoveTrayIcon();
    if (g_hookThreadHandle) {
        g_hookThreadRunning = false;
        WaitForSingleObject(g_hookThreadHandle, 2000);
        CloseHandle(g_hookThreadHandle);
        g_hookThreadHandle = NULL;
    }
    if (hInputThread) {
        WaitForSingleObject(hInputThread, 1000);
        CloseHandle(hInputThread);
    }
    HWND hCon = GetConsoleWindow();
    ShowWindow(hCon, SW_SHOW);
    cout << "程序已完全退出。" << endl;
    system("pause");
    return 0;
}